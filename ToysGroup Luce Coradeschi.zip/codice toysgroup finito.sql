-- CREAZIONE DB

CREATE database ToysGroup;

use ToysGroup;

-- CREAZIONE TABELLE

CREATE TABLE Category (
CategoryID INT AUTO_INCREMENT PRIMARY KEY,
CategoryName VARCHAR (100)

);


CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(200),
    UnitPrice DECIMAL(10,2),
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
    
    );
    
    CREATE TABLE Area (
    AreaID INT AUTO_INCREMENT PRIMARY KEY,
    AreaName VARCHAR (100)
    
    );
    
    CREATE TABLE State (
    StateID INT AUTO_INCREMENT PRIMARY KEY,
    StateName VARCHAR (250),
    AreaID INT,
    FOREIGN KEY (AreaID) REFERENCES Area(AreaID)
    
    );
    
    CREATE TABLE Sales (
    SalesID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT,
    Qty INT,
    SalesDate DATE,
    CategoryID INT,
    StateID INT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),
    FOREIGN KEY (StateID) REFERENCES State(StateID)
    
    );
    
    -- POPOLAMENTO TABELLE
    
    INSERT INTO Area (AreaID, AreaName)
    VALUES 
   (1, 'Europe'),
   (2, 'North America'),
   (3, 'Asia'),
   (4, 'South America')
   ;
   
    INSERT INTO Category (CategoryID, CategoryName)
    VALUES 
   (1, 'Stuffed Toys'),
   (2, 'Dolls and Accessories'),
   (3, 'Board Games'),
   (4, 'Educational toys/games')
   ;
   
    INSERT INTO Product (ProductID, ProductName,ProductDescription,UnitPrice, CategoryID)
    VALUES 
   (1, 'Spongebob', 'Stuffed Spongebob character',15.00, 1),
   (2, 'Barbie', 'Doll', 17.00,2),
   (3, 'Monopoly', 'Trading board game',40.00, 3),
   (4, 'Sailor Moon puzzle', 'Animated character puzzle',24.00,4),
   (5, 'Princess tiara', 'Toy tiara', 8.50, 2),
   (6, 'Bratz', 'Doll', 12.50, 2),
   (7, 'Bugs Bunny', 'Stuffed looney tunes character', 11.80,1),
   (8, 'Risiko', 'Board game', 60.00,3),
   (9, 'Operation', 'Surgeon simulation game', 32.00, 4),
   (10, 'Goku', 'Dragonball action figure', 43.00, 2)
   
;

INSERT INTO State (StateID, StateName,AreaID)
    VALUES
(1, 'Italy', 1),
(2,'Germany', 1),
(3, 'California', 2),
(4,'Colombia', 4),
(5,'New Jersey', 2),
(6, 'China', 3),
(7, 'Argentina', 4),
(8, 'Florida', 2)

;

INSERT INTO Sales (SalesID, ProductID,Qty, SalesDate, CategoryID, StateID)
    VALUES 
   (1, 1, 7, '2023-05-12', 1, 1),
   (2, 2, 20, '2022-04-03', 2, 3),
   (3, 3, 58, '2022-04-17', 3, 2),
   (4, 4, 92, '2022-11-25', 4, 4),
   (5, 5, 129, '2023-07-07', 2, 2),
   (6, 6, 24, '2023-08-08', 2, 3),
   (7, 7, 65, '2023-09-12', 1, 5),
   (8, 8, 47, '2021-12-31', 3, 5),
   (9, 9, 231, '2022-06-23', 4, 7),
   (10, 10, 9, '2021-05-19', 2, 8),
   (11, 1, 15, '2021-11-06', 1, 4),
   (12, 3, 55, '2023-03-09', 3, 1)
   
   ;
   
   SELECT * FROM state;
   
-- VERIFICARE UNIVOCITA PK

SELECT CategoryID  , COUNT(*)
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1
;

SELECT ProductID, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1
;


SELECT AreaID, COUNT(*)
FROM Area
GROUP BY AreaID
HAVING COUNT(*) > 1
;

SELECT StateID, COUNT(*)
FROM State
GROUP BY StateID
HAVING COUNT(*) > 1
;

SELECT SalesID, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1
;

-- elenco dei prodotti venduti + fatturato totale per anno

SELECT 
    YEAR(s.SalesDate) AS Year,
    p.ProductName,
    SUM(s.Qty * p.UnitPrice) AS TotalRevenue
FROM 
    sales s
JOIN 
    product p ON s.ProductID = p.ProductID
GROUP BY 
    Year, p.ProductName
    
    ;
    
    -- fatturato totale raggruppato per stato e per anno ordinato per data e fatt decre.
    
SELECT 
    DATE_FORMAT(s.SalesDate, '%Y-%m-%d') AS SalesDate,
    st.StateName,
    SUM(s.Qty * p.UnitPrice) AS TotalRevenue
FROM 
    SaleS s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN
    State st ON s.StateID = st.StateID
GROUP BY 
    SalesDate, st.StateName
ORDER BY 
    SalesDate, TotalRevenue DESC
    
    ;


-- Quale categora di prodotto e' piu richiesta sul mercato?

SELECT 

    c.CategoryName,
    SUM(s.Qty) AS TotalQuantity
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN
    Category c ON p.CategoryID = c.CategoryID
GROUP BY 
    c.CategoryID, c.CategoryName
ORDER BY 
    TotalQuantity DESC
    
    ;
    
-- risposta: in base ai dati visualizzati in questa query emerge una maggiore richiesta di Educational toys and games 


-- Ci sono prodotti invenduti?

    SELECT 
    p.ProductID,
    p.ProductName
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
WHERE 
    s.SalesID IS NULL
    
    ;

/*
 risposta: grazie a questa query ho chiesto di unire le tabelle Product e Sales, selezionando tutti i prodotti della Tabella product
 e ho chiesto i visualizzare un elenco dei prodotti ai quali non corrisponde una vendita nella tabella Sales. 
 Non ha restiuito nulla, quindi deduco che non ci siano prodotti invenduti. ToysGroup, continua cosi!
 
 */
 
 -- elenco prodotti con ultima data di vendita
 
 SELECT 
    p.ProductName,
    MAX(s.SalesDate) AS LastSaleDate
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductName
ORDER BY LastSaleDate 
    
    ;
    
  









    
    



